package com.example.praktikum_4;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new Instagram("nikeidn","Nike Indonesia"
                ,"Nike Dunk Low 'Black White \uD83D\uDCA8\uD83D\uDD25"
                ,R.drawable.nike_profil,R.drawable.nike_post));

        instagrams1.add(new Instagram("adidasindonesia", "Adidas Indonesia"
                ,"Let’s groove to Samba season! Ini inspirasi gaya casual dalam menyambut akhir tahun \uD83D\uDC40"
                ,R.drawable.adidas_profil,R.drawable.adidas_post));

        instagrams1.add(new Instagram("onitsukatiger", "Onitsuka Tiger"
                ,"Now available in new colorways and materials, the GSM features a conventional midsole silhouette and soft suede overlays for a vintage finish."
                ,R.drawable.onit_profil, R.drawable.onit_post));

        instagrams1.add((new Instagram("vans.id","Vans Indonesia"
                ,"Bringing the new vibes in every step with Vans Slip-On Checkerboard! \uD83C\uDFC1"
                ,R.drawable.vans_profil,R.drawable.vans_post)));

        instagrams1.add(new Instagram("converse_id", "Converse Indonesia"
                ,"Koleksi favorit Chuck 70 kembali dengan tone warna yang lebih warm untuk menemanimu pada musim ini."
                ,R.drawable.converse_profil,R.drawable.converse_post));

        instagrams1.add(new Instagram("newbalance","New Balance"
                ,"A classic in any era. The 530 featuring hairy suede and canvas."
                ,R.drawable.nb_profil, R.drawable.nb_post));

        instagrams1.add(new Instagram("pumaindonesia","Puma"
                , "Embrace timeless elegance in the iconic PUMA Suede, the essential choice for trendsetters everywhere\uD83D\uDC5F"
                ,R.drawable.puma_profil,R.drawable.puma_post));

        instagrams1.add(new Instagram("asicsid","ASICS Indonesia"
                ,"Landasan yang nyaman dan transisi yang lembut. Memberikan kenyamanan tak tertandingi dalam sepatu terbaru GEL-NIMBUS 26."
                ,R.drawable.asics_profil, R.drawable.asics_post));

        instagrams1.add(new Instagram("lacoste", "Lacoste"
                ,"Embrace the timeless allure of Lacoste French elegance ✨\uD83D\uDC0A"
                ,R.drawable.lacoste_profil, R.drawable.lacoste_post));

        instagrams1.add(new Instagram("dcshoes_id", "DC Shoes Indonesia"
                ,"Apparel suited for everyday use \uD83D\uDC4A"
                ,R.drawable.dcshoes_profil, R.drawable.dcshoes_post));
        return instagrams1;
    }
}

