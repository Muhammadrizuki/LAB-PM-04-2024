package com.example.tugaspraktikum2;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView tvName, tvUsername, tvTitle, tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tvName = findViewById(R.id.textView_name);
        tvUsername = findViewById(R.id.textView_username);
        tvTitle = findViewById(R.id.textView_title);
        tvContent = findViewById(R.id.textView_content);

        tvName.setText(getIntent().getStringExtra("name")); // tv yg di MA3 mau diset dari MA1
        tvUsername.setText(getIntent().getStringExtra("username"));
        tvTitle.setText(getIntent().getStringExtra("title"));
        tvContent.setText(getIntent().getStringExtra("content"));

        ImageView imageView = findViewById(R.id.imageView);
        String imageUriString = getIntent().getStringExtra("image");

        if (imageUriString != null){
            Uri imageUri = Uri.parse(imageUriString);
            imageView.setImageURI(imageUri);
        }
    }
}