package com.example.tugaspraktikum2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    EditText edTitle, edContent;
    Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        edTitle = findViewById(R.id.editText_title);
        edContent = findViewById(R.id.editText_content);
        buttonSave = findViewById(R.id.save);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String image = getIntent().getStringExtra("image"); // ini 3 setelah dikirim dari MA1 aka n diterima di MA2
                String input_name = getIntent().getStringExtra("name");
                String input_username = getIntent().getStringExtra("username");
                String input_title = edTitle.getText().toString(); // ini masukkan title sm content
                String input_content = edContent.getText().toString();

                if (!input_title.isEmpty() && !input_content.isEmpty()){
                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class); // akan mengirim data dari MA2 ke MA3
                    intent.putExtra("image", image);
                    intent.putExtra("name", input_name);
                    intent.putExtra("username", input_username);
                    intent.putExtra("title", input_title);
                    intent.putExtra("content", input_content);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity2.this, "Harap isi kedua kolom", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}