package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder>{
//untuk menghubungkan data dalam ArrayList stories dengan tampilan item-item dalam RecyclerView.

    private final ArrayList<Story> stories;

    private Context context;

    public StoryAdapter(ArrayList<Story> stories, Context context) { //ArrayList yang berisi data objek Story.
        this.context = context;
        this.stories = stories;
    }

    @NonNull
    @Override
    //dipanggil saat RecyclerView membutuhkan sebuah ViewHolder baru.
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story,parent,false);
        return new ViewHolder(view);
    }

    @Override
    //dipanggil untuk menetapkan data dari objek Story ke ViewHolder.
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder, int position) {
        Story story = stories.get(position);
        holder.setData(story); //untuk menetapkan data Story ke tampilan.

        holder.imageView.setOnClickListener(v -> {
            if(stories.get(position).getImage().equals(R.drawable.nike)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nike);
                intent.putExtra("NAMA PROFILE", "nikeidn");
                intent.putExtra("STORY",R.drawable.sgnike);
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.adidas)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.adidas);
                intent.putExtra("NAMA PROFILE", "adidasindonesia");
                intent.putExtra("STORY",R.drawable.sgads);
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.onit)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.onit);
                intent.putExtra("NAMA PROFILE", "onitsukatiger");
                intent.putExtra("STORY",R.drawable.sgonit);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.vans)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.vans);
                intent.putExtra("NAMA PROFILE", "vans.id");
                intent.putExtra("STORY",R.drawable.sgvans);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.converse)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.converse);
                intent.putExtra("NAMA PROFILE", "converse_id");
                intent.putExtra("STORY",R.drawable.sgconv);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.nb)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nb);
                intent.putExtra("NAMA PROFILE", "newbalance");
                intent.putExtra("STORY",R.drawable.sgnb);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.puma)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.puma);
                intent.putExtra("NAMA PROFILE", "pumaindonesia");
                intent.putExtra("STORY",R.drawable.sgpuma);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.asics)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.asics);
                intent.putExtra("NAMA PROFILE", "asicsid");
                intent.putExtra("STORY",R.drawable.sgasics);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.lacoste)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.lacoste);
                intent.putExtra("NAMA PROFILE", "lacoste");
                intent.putExtra("STORY",R.drawable.sglac);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.dcshoes)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.dcshoes);
                intent.putExtra("NAMA PROFILE", "dcshoes_id");
                intent.putExtra("STORY",R.drawable.sgdc);
                context.startActivity(intent);
            }
        });


    }

    @Override
    //mengembalikan jumlah item dalam RecyclerView, yaitu jumlah elemen dalam ArrayList stories.
    public int getItemCount() {
        return stories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView imageView;
        private final TextView textView; //nama sg
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_nama); //item_Story.xml
            imageView = itemView.findViewById(R.id.iv_story);
        }

        public void setData(Story story) {
            textView.setText(story.getNama());
            imageView.setImageResource(story.getImage());
        };
    }
}
