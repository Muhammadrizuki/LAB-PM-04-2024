package com.example.myapplication;

import java.util.ArrayList;

public class DataSource { // kelas yg berisi data" (post dan story) yg akan ditampilkan di recyclerView

    public static ArrayList<Postingan> postingans = generateDummyPostingans(); //ArrayList yang berisi objek-objek Postingan

    private static ArrayList<Postingan> generateDummyPostingans() {
        ArrayList<Postingan> postingans = new ArrayList<>();
        postingans.add(new Postingan(R.drawable.nike,"nikeidn", R.drawable.postnike, "Nike Dunk Low 'Black White'"));
        postingans.add(new Postingan(R.drawable.adidas,"adidasindonesia", R.drawable.postads, "Adidas Samba OG"));
        postingans.add(new Postingan(R.drawable.onit,"onitsukatiger", R.drawable.postonit, "Onitsuka Tiger Tokuten"));
        postingans.add(new Postingan(R.drawable.vans,"vans.id", R.drawable.postvans, "Vans Checkerboard Picante"));
        postingans.add(new Postingan(R.drawable.converse,"converse_id", R.drawable.postconv, "Converse 70’s Chuck Low"));
        postingans.add(new Postingan(R.drawable.nb,"newbalance", R.drawable.postnb, "New Balance 530"));
        postingans.add(new Postingan(R.drawable.puma,"pumaindonesia", R.drawable.postpuma, "Puma Suede"));
        postingans.add(new Postingan(R.drawable.asics,"asicsid", R.drawable.postasc, "ASICS Women Gel-Nimbus 26"));
        postingans.add(new Postingan(R.drawable.lacoste,"lacoste", R.drawable.postlac, "Lacoste Women's"));
        postingans.add(new Postingan(R.drawable.dcshoes,"dcshoes_id", R.drawable.postdc, "DC Shoes"));
        return postingans;
    }

    public static ArrayList<Story> stories = generateDummyStorys(); //ArrayList yang berisi objek-objek Story

    private static ArrayList<Story> generateDummyStorys() {
        ArrayList<Story> stories = new ArrayList<>();
        stories.add(new Story("nikeidn",R.drawable.nike));
        stories.add(new Story("adidasindonesia",R.drawable.adidas));
        stories.add(new Story("onitsukatiger",R.drawable.onit));
        stories.add(new Story("vans.id",R.drawable.vans));
        stories.add(new Story("converse_id",R.drawable.converse));
        stories.add(new Story("newbalance",R.drawable.nb));
        stories.add(new Story("pumaindonesia",R.drawable.puma));
        stories.add(new Story("asicsid",R.drawable.asics));
        stories.add(new Story("lacoste",R.drawable.lacoste));
        stories.add(new Story("dcshoes_id",R.drawable.dcshoes));
        return stories;
    }
}
