package com.example.myapplication;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PostinganActivity extends Activity { //kelas untuk menampilkan detail postingan.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postingan_actvity);

        ImageView ivProfile = findViewById(R.id.iv_profile);
        TextView tvUsername = findViewById(R.id.tv_user);
        ImageView ivPost = findViewById(R.id.iv_post);
        TextView tvDesc = findViewById(R.id.tv_desc);

        Intent intent = getIntent();

        int fotoProfile = intent.getIntExtra("FOTO PROFILE",0);
        String username = intent.getStringExtra("USERNAME");
        int postingan = intent.getIntExtra("POSTINGAN", 0);
        String desc = intent.getStringExtra("DESKRIPSI");

        ivProfile.setImageResource(fotoProfile);
        tvUsername.setText(username);
        ivPost.setImageResource(postingan);
        tvDesc.setText(desc);

        ivProfile.setOnClickListener(v -> { //aktivitas klik pada gambar profil
            if(fotoProfile == R.drawable.nike){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.nike);
                Storyintent.putExtra("NAMA PROFILE", "nikeidn");
                Storyintent.putExtra("STORY",R.drawable.sgnike);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.adidas){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.adidas);
                Storyintent.putExtra("NAMA PROFILE", "adidasindonesia");
                Storyintent.putExtra("STORY",R.drawable.sgads);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.onit){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.onit);
                Storyintent.putExtra("NAMA PROFILE", "onitsukatiger");
                Storyintent.putExtra("STORY",R.drawable.sgonit);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.vans){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.vans);
                Storyintent.putExtra("NAMA PROFILE", "vans.id");
                Storyintent.putExtra("STORY",R.drawable.sgvans);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.converse){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.converse);
                Storyintent.putExtra("NAMA PROFILE", "converse_id");
                Storyintent.putExtra("STORY",R.drawable.sgconv);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.nb){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.nb);
                Storyintent.putExtra("NAMA PROFILE", "newbalance");
                Storyintent.putExtra("STORY",R.drawable.sgnb);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.puma){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.puma);
                Storyintent.putExtra("NAMA PROFILE", "pumaindonesia");
                Storyintent.putExtra("STORY",R.drawable.sgpuma);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.asics){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.asics);
                Storyintent.putExtra("NAMA PROFILE", "asicsid");
                Storyintent.putExtra("STORY",R.drawable.sgasics);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.lacoste){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.lacoste);
                Storyintent.putExtra("NAMA PROFILE", "lacoste");
                Storyintent.putExtra("STORY",R.drawable.sglac);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.dcshoes){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.dcshoes);
                Storyintent.putExtra("NAMA PROFILE", "dcshoes_id");
                Storyintent.putExtra("STORY",R.drawable.sgdc);
                startActivity(Storyintent);
            }
        });

        tvUsername.setOnClickListener(v -> { //Menangani klik pada nama pengguna
            if(username.equals("nikeidn")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.nike);
                profileIntent.putExtra("NAMA PROFILE","Nike Indonesia");
                profileIntent.putExtra("FOLLOWERS","1,1 JT");
                profileIntent.putExtra("FOLLOWING","205");
                profileIntent.putExtra("POSTINGAN", R.drawable.postnike);
                startActivity((profileIntent));
            }if(username.equals("adidasindonesia")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.adidas);
                profileIntent.putExtra("NAMA PROFILE","Adidas Indonesia");
                profileIntent.putExtra("FOLLOWERS","1 JT");
                profileIntent.putExtra("FOLLOWING","144");
                profileIntent.putExtra("POSTINGAN", R.drawable.postads);
                startActivity((profileIntent));
            } if(username.equals("onitsukatiger")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.onit);
                profileIntent.putExtra("NAMA PROFILE","Onitsuka Tiger");
                profileIntent.putExtra("FOLLOWERS","956K");
                profileIntent.putExtra("FOLLOWING","5.885");
                profileIntent.putExtra("POSTINGAN", R.drawable.postonit);
                startActivity((profileIntent));
            } if(username.equals("vans.id")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.vans);
                profileIntent.putExtra("NAMA PROFILE","vans.id");
                profileIntent.putExtra("FOLLOWERS","69,4K");
                profileIntent.putExtra("FOLLOWING","32");
                profileIntent.putExtra("POSTINGAN", R.drawable.postvans);
                startActivity((profileIntent));
            }if(username.equals("converse_id")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.converse);
                profileIntent.putExtra("NAMA PROFILE","Converse Indonesia");
                profileIntent.putExtra("FOLLOWERS","288K");
                profileIntent.putExtra("FOLLOWING","1");
                profileIntent.putExtra("POSTINGAN", R.drawable.postconv);
                startActivity((profileIntent));
            }if(username.equals("newbalance")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.nb);
                profileIntent.putExtra("NAMA PROFILE","New Balance");
                profileIntent.putExtra("FOLLOWERS","1,4 JT");
                profileIntent.putExtra("FOLLOWING","46");
                profileIntent.putExtra("POSTINGAN", R.drawable.postnb);
                startActivity((profileIntent));
            }if(username.equals("pumaindonesia")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.puma);
                profileIntent.putExtra("NAMA PROFILE","Puma");
                profileIntent.putExtra("FOLLOWERS","157K");
                profileIntent.putExtra("FOLLOWING","56");
                profileIntent.putExtra("POSTINGAN", R.drawable.postpuma);
                startActivity((profileIntent));
            } if(username.equals("asicsid")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.asics);
                profileIntent.putExtra("NAMA PROFILE","ASICS Indonesia");
                profileIntent.putExtra("FOLLOWERS","1,1 JT");
                profileIntent.putExtra("FOLLOWING","129");
                profileIntent.putExtra("POSTINGAN", R.drawable.postasc);
                startActivity((profileIntent));
            }if(username.equals("lacoste")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.lacoste);
                profileIntent.putExtra("NAMA PROFILE","Lacoste");
                profileIntent.putExtra("FOLLOWERS","340K");
                profileIntent.putExtra("FOLLOWING","27");
                profileIntent.putExtra("POSTINGAN", R.drawable.postlac);
                startActivity((profileIntent));
            } if(username.equals("dcshoes_id")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.dcshoes);
                profileIntent.putExtra("NAMA PROFILE","dcshoes_id");
                profileIntent.putExtra("FOLLOWERS","76,1 JT");
                profileIntent.putExtra("FOLLOWING","198");
                profileIntent.putExtra("POSTINGAN", R.drawable.postdc);
                startActivity((profileIntent));
            }
        });
    }

}
