package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostinganAdapter extends RecyclerView.Adapter<PostinganAdapter.ViewHolder> {
    // tampilan daftar postingan dengan menggunakan data yang disediakan dalam ArrayList postingans.

    private final ArrayList<Postingan> postingans;

    private Context context;

    public PostinganAdapter(ArrayList<Postingan> postingans, Context context) {
        this.context = context;
        this.postingans = postingans;
    }

    @NonNull
    @Override
    public PostinganAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //tampilan
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostinganAdapter.ViewHolder holder, int position) {
        Postingan postingan = postingans.get(position);
        holder.setData(postingan); //Data dari objek Postingan pada posisi yang diberikan diambil dan ditetapkan ke ViewHolder

        holder.tvUser.setOnClickListener(v -> {
            if(postingans.get(position).getUsername().equals("nikeidn")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nike);
                intent.putExtra("NAMA PROFILE","Nike");
                intent.putExtra("FOLLOWERS","1,5 JT");
                intent.putExtra("FOLLOWING","5");
                intent.putExtra("POSTINGAN", R.drawable.postnike);
                context.startActivity(intent);
            }  if(postingans.get(position).getUsername().equals("adidasindonesia")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.adidas);
                intent.putExtra("NAMA PROFILE","Adidas Indonesia");
                intent.putExtra("FOLLOWERS","8,6 JT");
                intent.putExtra("FOLLOWING","4");
                intent.putExtra("POSTINGAN", R.drawable.postads);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("onitsukatiger")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.onit);
                intent.putExtra("NAMA PROFILE","Onitsuka Tiger");
                intent.putExtra("FOLLOWERS","13,5 JT");
                intent.putExtra("FOLLOWING","6.452");
                intent.putExtra("POSTINGAN", R.drawable.postonit);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("vans.id")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.vans);
                intent.putExtra("NAMA PROFILE","Vans Indonesia");
                intent.putExtra("FOLLOWERS","1,3 JT");
                intent.putExtra("FOLLOWING","172");
                intent.putExtra("POSTINGAN", R.drawable.postvans);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("converse_id")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.converse);
                intent.putExtra("NAMA PROFILE","Converse Indonesia");
                intent.putExtra("FOLLOWERS","6,9 JT");
                intent.putExtra("FOLLOWING","1");
                intent.putExtra("POSTINGAN", R.drawable.postconv);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("newbalance")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nb);
                intent.putExtra("NAMA PROFILE","New Balance");
                intent.putExtra("FOLLOWERS","9,9 JT");
                intent.putExtra("FOLLOWING","1");
                intent.putExtra("POSTINGAN", R.drawable.postnb);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("pumaindonesia")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.puma);
                intent.putExtra("NAMA PROFILE","Puma");
                intent.putExtra("FOLLOWERS","17,6 JT");
                intent.putExtra("FOLLOWING","0");
                intent.putExtra("POSTINGAN", R.drawable.postpuma);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("asicsid")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.asics);
                intent.putExtra("NAMA PROFILE","ASICS Indonesia");
                intent.putExtra("FOLLOWERS","3,4 JT");
                intent.putExtra("FOLLOWING","0");
                intent.putExtra("POSTINGAN", R.drawable.postasc);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("lacoste")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.lacoste);
                intent.putExtra("NAMA PROFILE","Lacoste");
                intent.putExtra("FOLLOWERS","5,4 JT");
                intent.putExtra("FOLLOWING","3");
                intent.putExtra("POSTINGAN", R.drawable.postlac);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("dcshoes_id")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.dcshoes);
                intent.putExtra("NAMA PROFILE","DC Shoes Indonesia");
                intent.putExtra("FOLLOWERS","2,4 JT");
                intent.putExtra("FOLLOWING","1");
                intent.putExtra("POSTINGAN", R.drawable.postdc);
                context.startActivity(intent);
            }
        });

        holder.imageView2.setOnClickListener(v -> {
            if(postingans.get(position).getUsername().equals("nikeidn")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nike);
                intent.putExtra("NAMA PROFILE", "nikeidn");
                intent.putExtra("STORY",R.drawable.sgnike);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("adidasindonesia")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.adidas);
                intent.putExtra("NAMA PROFILE", "adidasindonesia");
                intent.putExtra("STORY",R.drawable.sgads);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("onitsukatiger")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.onit);
                intent.putExtra("NAMA PROFILE", "onitsukatiger");
                intent.putExtra("STORY",R.drawable.sgonit);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("vans.id")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.vans);
                intent.putExtra("NAMA PROFILE", "vans.id");
                intent.putExtra("STORY",R.drawable.sgvans);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("converse_id")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.converse);
                intent.putExtra("NAMA PROFILE", "converse_id");
                intent.putExtra("STORY",R.drawable.sgconv);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("newbalance")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.nb);
                intent.putExtra("NAMA PROFILE", "newbalance");
                intent.putExtra("STORY",R.drawable.sgnb);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("pumaindonesia")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.puma);
                intent.putExtra("NAMA PROFILE", "pumaindonesia");
                intent.putExtra("STORY",R.drawable.sgpuma);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("asicsid")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.asics);
                intent.putExtra("NAMA PROFILE", "asicsid");
                intent.putExtra("STORY",R.drawable.sgasics);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("lacoste")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.lacoste);
                intent.putExtra("NAMA PROFILE", "lacoste");
                intent.putExtra("STORY",R.drawable.sglac);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("dcshoes_id")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.dcshoes);
                intent.putExtra("NAMA PROFILE", "dcshoes_id");
                intent.putExtra("STORY",R.drawable.sgdc);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return postingans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder { //untuk menyimpan referensi ke elemen UI dalam layout item postingan.

        private final ImageView imageView, imageView2;

        private final TextView tvUser, tvDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView2 = itemView.findViewById(R.id.iv_profile);
            imageView = itemView.findViewById(R.id.iv_post);
            tvUser = itemView.findViewById(R.id.tv_user);
            tvDesc = itemView.findViewById(R.id.tv_desc);
        }

        public void setData(Postingan postingan) { //setData() digunakan untuk menetapkan data dari objek Postingan ke ViewHolder.
            imageView2.setImageResource(postingan.getImage2());
            imageView.setImageResource(postingan.getImage());
            tvUser.setText(postingan.getUsername());
            tvDesc.setText(postingan.getDesc());
        }
    }
}
