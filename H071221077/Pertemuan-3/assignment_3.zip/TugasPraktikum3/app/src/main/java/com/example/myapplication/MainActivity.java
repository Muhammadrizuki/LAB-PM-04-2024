package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView shoesPostingan = findViewById(R.id.shoes_post);
        shoesPostingan.setHasFixedSize(true);

        PostinganAdapter postinganAdapter = new PostinganAdapter(DataSource.postingans,this);
        shoesPostingan.setAdapter(postinganAdapter);

        RecyclerView shoesStory = findViewById(R.id.shoes_story);
        shoesStory.setHasFixedSize(true);

        StoryAdapter storyAdapter = new StoryAdapter(DataSource.stories, this);
        shoesStory.setAdapter(storyAdapter);
    }
}