package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView ivProfile = findViewById(R.id.iv_profile); //activity_profile.xml
        TextView tvProfile = findViewById(R.id.Tv_profile);
        TextView tvAngkaFollowers = findViewById(R.id.Tv_followers);
        TextView tvAngkaFollowing = findViewById(R.id.Tv_following);
        ImageView ivPost = findViewById(R.id.iv_post);

        Intent intent = getIntent(); //Mengambil data dari intent yang memulai aktivitas ini

        int fotoProfile = intent.getIntExtra("FOTO PROFILE", 0);
        String namaProfile = intent.getStringExtra("NAMA PROFILE");
        String angkaFollowers = intent.getStringExtra("FOLLOWERS");
        String angkaFollowing = intent.getStringExtra("FOLLOWING");
        int postingan = intent.getIntExtra("POSTINGAN", 0); //Mengambil data yang dikirimkan melalui intent

        ivProfile.setImageResource(fotoProfile);
        tvProfile.setText(namaProfile);
        tvAngkaFollowers.setText(angkaFollowers);
        tvAngkaFollowing.setText(angkaFollowing);
        ivPost.setImageResource(postingan);

        ivProfile.setOnClickListener(v -> {
            if (fotoProfile == R.drawable.nike) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.nike);
                storyIntent.putExtra("NAMA PROFILE", "nikeidn");
                storyIntent.putExtra("STORY", R.drawable.sgnike);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.adidas) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.adidas);
                storyIntent.putExtra("NAMA PROFILE", "adidasindonesia");
                storyIntent.putExtra("STORY", R.drawable.sgads);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.onit) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.onit);
                storyIntent.putExtra("NAMA PROFILE", "onitsukatiger");
                storyIntent.putExtra("STORY", R.drawable.sgonit);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.vans) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.vans);
                storyIntent.putExtra("NAMA PROFILE", "vans.id");
                storyIntent.putExtra("STORY", R.drawable.sgvans);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.converse) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.converse);
                storyIntent.putExtra("NAMA PROFILE", "converse_id");
                storyIntent.putExtra("STORY", R.drawable.sgconv);
                startActivity(storyIntent);
            }  if (fotoProfile == R.drawable.nb) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.nb);
                storyIntent.putExtra("NAMA PROFILE", "newbalance");
                storyIntent.putExtra("STORY", R.drawable.sgnb);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.puma) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.puma);
                storyIntent.putExtra("NAMA PROFILE", "pumaindonesia");
                storyIntent.putExtra("STORY", R.drawable.sgpuma);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.asics) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.asics);
                storyIntent.putExtra("NAMA PROFILE", "asicsid");
                storyIntent.putExtra("STORY", R.drawable.sgasics);
                startActivity(storyIntent);
            } else if (fotoProfile == R.drawable.lacoste) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.lacoste);
                storyIntent.putExtra("NAMA PROFILE", "lacoste");
                storyIntent.putExtra("STORY", R.drawable.sglac);
                startActivity(storyIntent);
            } else if (fotoProfile == R.drawable.dcshoes) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.dcshoes);
                storyIntent.putExtra("NAMA PROFILE", "dcshoes_id");
                storyIntent.putExtra("STORY", R.drawable.sgdc);
                startActivity(storyIntent);
            }
        });

        ivPost.setOnClickListener(v -> {
            if (postingan == R.drawable.postnike) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.nike);
                storyIntent.putExtra("USERNAME", "nikeidn");
                storyIntent.putExtra("POSTINGAN", R.drawable.postnike);
                storyIntent.putExtra("DESKRIPSI", "Nike Dunk Low 'Black White'");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postads) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.adidas);
                storyIntent.putExtra("USERNAME", "adidasindonesia");
                storyIntent.putExtra("POSTINGAN", R.drawable.postads);
                storyIntent.putExtra("DESKRIPSI", "Adidas Samba OG");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postonit) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.onit);
                storyIntent.putExtra("USERNAME", "onitsukatiger");
                storyIntent.putExtra("POSTINGAN", R.drawable.postonit);
                storyIntent.putExtra("DESKRIPSI", "Onitsuka Tiger Tokuten");
                startActivity(storyIntent);
            }if (postingan == R.drawable.postvans) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.vans);
                storyIntent.putExtra("USERNAME", "vans.id");
                storyIntent.putExtra("POSTINGAN", R.drawable.postvans);
                storyIntent.putExtra("DESKRIPSI", "Vans Checkerboard Picante");
                startActivity(storyIntent);
            }if (postingan == R.drawable.postconv) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.converse);
                storyIntent.putExtra("USERNAME", "converse_id");
                storyIntent.putExtra("POSTINGAN", R.drawable.postconv);
                storyIntent.putExtra("DESKRIPSI", "Converse 70’s Chuck Low");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postnb) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.nb);
                storyIntent.putExtra("USERNAME", "newbalance");
                storyIntent.putExtra("POSTINGAN", R.drawable.postnb);
                storyIntent.putExtra("DESKRIPSI", "New Balance 530");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postpuma) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.puma);
                storyIntent.putExtra("USERNAME", "pumaindonesia");
                storyIntent.putExtra("POSTINGAN", R.drawable.postpuma);
                storyIntent.putExtra("DESKRIPSI", "Puma Suede");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postasc) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.asics);
                storyIntent.putExtra("USERNAME", "asicsid");
                storyIntent.putExtra("POSTINGAN", R.drawable.postasc);
                storyIntent.putExtra("DESKRIPSI", "ASICS Women Gel-Nimbus 26");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postlac) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.lacoste);
                storyIntent.putExtra("USERNAME", "lacoste");
                storyIntent.putExtra("POSTINGAN", R.drawable.postlac);
                storyIntent.putExtra("DESKRIPSI", "Lacoste Women's");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postdc) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.dcshoes);
                storyIntent.putExtra("USERNAME", "dcshoes_id");
                storyIntent.putExtra("POSTINGAN", R.drawable.postdc);
                storyIntent.putExtra("DESKRIPSI", "DC Shoes");
                startActivity(storyIntent);
            }
        });
    }
}
