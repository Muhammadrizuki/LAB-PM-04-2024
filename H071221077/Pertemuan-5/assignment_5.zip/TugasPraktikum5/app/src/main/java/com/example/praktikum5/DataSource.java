package com.example.praktikum5;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams =generateDummyInstagram();

    private static ArrayList<Instagram> generateDummyInstagram() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new Instagram("footlockerid", "Foot Locker Indonesia",
                "Save big at Foot Locker! \uD83D\uDCB0 Grab your second item at 30% off online and in-store until April 28."
                ,R.drawable.footlocker_profil, R.drawable.footlocker_post));

        instagrams1.add(new Instagram("nikeidn", "Nike Indonesia",
                "Nike Dunk Low 'Black White \uD83D\uDCA8\uD83D\uDD25"
                ,R.drawable.nike_profil, R.drawable.nike_post));

        instagrams1.add(new Instagram("adidasindonesia", "Adidas Indonesia",
                "Let’s groove to Samba season! Ini inspirasi gaya casual dalam menyambut akhir tahun \uD83D\uDC40"
                ,R.drawable.adidas_profil, R.drawable.adidas_post));

        instagrams1.add(new Instagram("onitsukatiger", "Onitsuka Tiger",
                "Now available in new colorways and materials, the GSM features a conventional midsole silhouette and soft suede overlays for a vintage finish."
                ,R.drawable.onit_profil, R.drawable.onit_post));

        instagrams1.add(new Instagram("vans.id", "Vans Indonesia",
                "Bringing the new vibes in every step with Vans Slip-On Checkerboard! \uD83C\uDFC1"
                ,R.drawable.vans_profil, R.drawable.vans_post));

        return instagrams1;

    }

}

