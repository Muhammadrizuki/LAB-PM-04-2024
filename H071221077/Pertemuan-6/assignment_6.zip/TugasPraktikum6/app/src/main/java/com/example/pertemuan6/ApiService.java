package com.example.pertemuan6;

import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    @GET("api/users?page={page}&per_page={per_page}")
    Call<UserResponse> getUsers(@Path("page") int page, @Path("per_page") int per_page);

    @GET("api/users/{id}")
    Call<UserResponse2> getUserById(@Path("id") int userId);

}