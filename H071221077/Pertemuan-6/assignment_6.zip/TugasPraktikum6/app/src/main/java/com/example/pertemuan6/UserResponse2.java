package com.example.pertemuan6;

import java.util.List;

public class UserResponse2 {
    private User data;
    public User getData() {
        return data;
    }

}
