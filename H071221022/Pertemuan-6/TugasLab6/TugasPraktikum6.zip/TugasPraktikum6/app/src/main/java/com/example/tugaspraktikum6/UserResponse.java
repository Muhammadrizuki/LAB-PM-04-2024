package com.example.tugaspraktikum6;

import java.util.List;

public class UserResponse {
    public List<User> getData() {
        return data;
    }

    public void setData(List<User> data) {
        this.data = data;
    }

    private List<User> data ;


}
