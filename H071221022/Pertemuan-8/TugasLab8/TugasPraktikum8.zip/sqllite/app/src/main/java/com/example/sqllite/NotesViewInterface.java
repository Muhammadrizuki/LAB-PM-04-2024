package com.example.sqllite;

public interface NotesViewInterface {
    void onItemClickToEdit(int position);
}
