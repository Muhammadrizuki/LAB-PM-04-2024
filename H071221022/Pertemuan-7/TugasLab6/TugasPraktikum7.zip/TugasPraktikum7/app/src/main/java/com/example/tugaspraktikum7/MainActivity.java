package com.example.tugaspraktikum7;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;

import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;


public class MainActivity extends AppCompatActivity {

    private static final String NAME_SP = "MyFile";
    private EditText nim ;
    private EditText pass;
    private Button login;
    private Button regis;
    private Boolean isLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nim = findViewById(R.id.et1_nim);
        pass = findViewById(R.id.et1_pass);
        login = findViewById(R.id.bt_login);
        regis = findViewById(R.id.bt_regis);

        SharedPreferences sharedPreferences = getSharedPreferences(NAME_SP, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        String nim_1 = sharedPreferences.getString("nim", "");
        String pass_1 = sharedPreferences.getString("pass", "");
        Boolean isMasuk = sharedPreferences.getBoolean("isLogin",false);
        Boolean isDarkMode = sharedPreferences.getBoolean("darkmode", false);
        changeMode(isDarkMode);
        if (isMasuk){
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
            finish();
        }
        login.setOnClickListener(e->{
            Boolean nim_kosong = TextUtils.isEmpty(nim.getText().toString());
            Boolean pass_kosong = TextUtils.isEmpty(pass.getText().toString());

            if ((nim_kosong) && (pass_kosong)){
                isLogin = false;
            }else if(nim_kosong){
                isLogin = false;
            }
            else if(pass_kosong){
                isLogin = false;
            }else{
                isLogin = true;
            }
            if(isLogin && (nim_1.equals(nim.getText().toString()) )&& (pass_1.equals(pass.getText().toString()))){
                editor.putBoolean("isLogin", true);
                editor.apply();
                editor.commit();
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra("nim", nim_1);
                startActivity(intent);
                finish();
            }else if(!isLogin){
                if (nim.getText() == null){
                    nim.setError("Masukkan Nim");
                }
                else if(pass.getText() == null){
                    pass.setError("Masukkan Pass");
                }else {
                    nim.setError("Masukkan Nim");
                    pass.setError("Masukkan Pass");
                }
            }else if(!(nim_1.equals(nim.getText().toString()))){
                nim.setError("Nim Salah");
            }else if(!(pass_1.equals(pass.getText().toString()))) {
                nim.setError("Password Salah");
            }

        });

        regis.setOnClickListener(e ->{
            Intent intent = new Intent(this, RegisActivity.class);
            startActivity(intent);

        });

    }
    private void darkMode(){
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }
    private void lightMode(){
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }
    private void changeMode(Boolean isDarkMode){
        if (isDarkMode) {
            // Dark Mode
            darkMode();
        } else if(!isDarkMode){
            // Light Mode
            lightMode();
        }
    }
}