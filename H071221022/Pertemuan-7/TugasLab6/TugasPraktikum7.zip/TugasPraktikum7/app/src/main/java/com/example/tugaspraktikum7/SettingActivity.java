package com.example.tugaspraktikum7;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;


public class SettingActivity extends AppCompatActivity {
    private Switch darkMode;
    private static final String NAME_SP = "MyFile";
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        darkMode = findViewById(R.id.darkmode);

        sharedPreferences = getSharedPreferences(NAME_SP, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        boolean isDarkTheme = sharedPreferences.getBoolean("darkmode", false);
        darkMode.setChecked(isDarkTheme);
        darkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Memeriksa apakah Switch diaktifkan
            if (isChecked) {
                // Dark Mode
                darkMode();
            } else {
                // Light Mode
                lightMode();
            }
            editor.putBoolean("darkmode", isChecked);
            editor.apply();
        });
    }
    private void darkMode(){
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }
    private void lightMode(){
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }
    private void changeMode(Boolean isDarkMode){
        if (isDarkMode) {
            // Dark Mode
            darkMode();
        } else if(!isDarkMode){
            // Light Mode
            lightMode();
        }
    }
}