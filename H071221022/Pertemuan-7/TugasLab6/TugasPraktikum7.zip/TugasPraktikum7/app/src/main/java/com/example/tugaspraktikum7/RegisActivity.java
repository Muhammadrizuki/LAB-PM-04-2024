package com.example.tugaspraktikum7;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisActivity extends AppCompatActivity {

    private static final String NAME_SP = "MyFile";
    private EditText nim ;
    private EditText pass;
    private Button regis;
    private Boolean isLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regis);

        nim = findViewById(R.id.rg_nim);
        pass = findViewById(R.id.rg_pass);
        regis = findViewById(R.id.rg_regis);


        SharedPreferences sharedPreferences = getSharedPreferences(NAME_SP, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        regis.setOnClickListener(e->{
            Boolean nim_kosong = TextUtils.isEmpty(nim.getText().toString());
            Boolean pass_kosong = TextUtils.isEmpty(pass.getText().toString());
            if ( (nim_kosong)&& (pass_kosong) ){
                nim.setError("Masukkan Nim");
                pass.setError("Masukkan Pass");
                isLogin = false;
            }else if(nim_kosong){
                nim.setError("Masukkan Nim");
                isLogin = false;
            }
            else if(pass_kosong){
                pass.setError("Masukkan Pass");
                isLogin = false;
            }
            else {
                editor.putString("nim", nim.getText().toString());
                editor.putString("pass", pass.getText().toString());
                editor.apply();
                editor.commit();
                String nim_1 = sharedPreferences.getString("nim", "");
                String pass_1 = sharedPreferences.getString("pass", "");

                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }

        });

    }
}