package com.example.tugaspraktikum7;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomeActivity extends AppCompatActivity {
    private TextView welcome;
    private Button logout;
    private Button setting;
    private static final String NAME_SP = "MyFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        welcome = findViewById(R.id.welcome);
        logout = findViewById(R.id.bt_logout);
        setting = findViewById(R.id.bt_setting);

        SharedPreferences sharedPreferences = getSharedPreferences(NAME_SP, Context.MODE_PRIVATE);

        String nim = sharedPreferences.getString("nim", "");

        welcome.setText("Selamat datang " + nim);
        logout.setOnClickListener(e->{
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isLogin", false);
            editor.apply();
            editor.commit();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
        setting.setOnClickListener(e->{
            Intent intent = new Intent(this, SettingActivity.class);

            startActivity(intent);

        });

    }
}