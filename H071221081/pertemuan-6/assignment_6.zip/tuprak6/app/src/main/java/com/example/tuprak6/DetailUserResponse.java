package com.example.tuprak6;

import java.util.List;

public class DetailUserResponse {

    private User data;
    public User getData() {
        return data;
    }
    public void setData(User data) {
        this.data = data;
    }
}
