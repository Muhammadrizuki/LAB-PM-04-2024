package com.example.prak5backgroundthread;

import com.example.prak5backgroundthread.R;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<com.example.prak5backgroundthread.Instagram> instagrams =generateDummyInstagram();

    private static ArrayList<com.example.prak5backgroundthread.Instagram> generateDummyInstagram() {
        ArrayList<com.example.prak5backgroundthread.Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new com.example.prak5backgroundthread.Instagram("nabiilasyh", "Nabila Kharisma", "nabiilasyh | In a world of filters, be your own authentic self"
                , R.drawable.foto1, R.drawable.foto1));

        instagrams1.add(new com.example.prak5backgroundthread.Instagram("fadillahcheryl", "Fadillah Cheryl", "fadillahcheryl | Making memories around the world"
                ,R.drawable.foto2, R.drawable.foto2));

        instagrams1.add(new com.example.prak5backgroundthread.Instagram("putrinakitam", "Putri Nakita Munsi", "putrinakitam | Haters gonna hate, I’m gonna keep shining"
                ,R.drawable.foto3, R.drawable.foto3));

        instagrams1.add(new com.example.prak5backgroundthread.Instagram("afifahsalsabila_", "Afifah Salsabila", "afifahsalsabila_ | Embracing the beauty of imperfections"
                ,R.drawable.foto4, R.drawable.foto4));

        instagrams1.add(new com.example.prak5backgroundthread.Instagram("fraaulia_", "Fara Aulia", "fraaulia_ | Unveiling the beauty of the ordinary"
                ,R.drawable.foto5, R.drawable.foto5));

        return instagrams1;

    }

}


