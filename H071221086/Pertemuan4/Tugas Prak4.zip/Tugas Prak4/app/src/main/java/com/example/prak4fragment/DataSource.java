package com.example.prak4fragment;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();

        instagrams1.add(new Instagram("nabiilasyh", "Nabila kharisma"
                , "nabiilasyh | in a world full of trends, i want to remain a classic"
                , R.drawable.post1, R.drawable.post1));

        instagrams1.add(new Instagram("auliyaspryg", "Auliya suprayogi"
                , "auliyaspryg | life is a journey to be experienced, not a problem to be solved."
                , R.drawable.post2, R.drawable.post2));

        instagrams1.add(new Instagram("fadillahcheryl", "Fadillah Cheryl A "
                , "fadillahcheryl | be the reason someone believes in the goodness of people."
                , R.drawable.post3, R.drawable.post3));

        instagrams1.add((new Instagram("nadjwaaj", "Nadjwa amalia"
                , "nadjwaaj | find joy in the journey, not just the destination."
                , R.drawable.post4, R.drawable.post4)));

        instagrams1.add(new Instagram("fraaulia_", "Fara Aulia A.S"
                , "fraaulia_ | true love doesn’t have a happy ending. It doesn’t have an ending at al"
                , R.drawable.post5, R.drawable.post5));

        instagrams1.add(new Instagram("raihanahr", "Arni raihana"
                , "raihanahr | love is when imperfection being perfection"
                , R.drawable.post6, R.drawable.post6));

        return instagrams1;

    }
}
