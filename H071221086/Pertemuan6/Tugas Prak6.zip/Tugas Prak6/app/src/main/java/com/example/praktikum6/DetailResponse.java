package com.example.praktikum6;

public class DetailResponse {

    private User data;
    public User getData() {
        return data;
    }
    public void setData(User data) {
        this.data = data;
    }
}
