package com.example.praktikum3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PostinganActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postingan);

        ImageView postingan = findViewById(R.id.post_image);
        TextView username = findViewById(R.id.username);
        TextView caption = findViewById(R.id.post_caption);

        Intent intent = getIntent();

        int post = intent.getIntExtra("postingan", 0);
        String name = intent.getStringExtra("username");
        String capt = intent.getStringExtra("caption");

        postingan.setImageResource(post);
        username.setText(name);
        caption.setText(capt);

        username.setOnClickListener(v -> {
            if(name.equals("biwarchive")){
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil",R.drawable.kucing1);
                intent1.putExtra("username","biwarchive");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil",R.drawable.post1);
                startActivity(intent1);
            }if(name.equals("xisalsaa")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil",R.drawable.kucing2);
                intent1.putExtra("username","xisalsaa");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil",R.drawable.post2);
                startActivity(intent1);
            }if(name.equals("nakitssss")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil",R.drawable.kucing3);
                intent1.putExtra("username","nakitssss");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil",R.drawable.post3);
                startActivity(intent1);
            }if(name.equals("serilll")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil",R.drawable.kucing4);
                intent1.putExtra("username","serilll");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil",R.drawable.post4);
                startActivity(intent1);
            }if(name.equals("dipsieyyy")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing5);
                intent1.putExtra("username", "dipsieyyy");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post5);
                startActivity(intent1);
            }if(name.equals("raihnhr")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing6);
                intent1.putExtra("username", "raihnhr");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post6);
                startActivity(intent1);
            }if(name.equals("awinkkk")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing7);
                intent1.putExtra("username", "awinkk");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post7);
                startActivity(intent1);
            }if(name.equals("auliyaspryg")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing8);
                intent1.putExtra("username", "auliyaspryg");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post8);
                startActivity(intent1);
            }if(name.equals("yumyeyyy")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing9);
                intent1.putExtra("username", "yumyeyyy");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post9);
                startActivity(intent1);
            }if(name.equals("ay.yay_")) {
                Intent intent1 = new Intent(PostinganActivity.this, ProfileActivity.class);
                intent1.putExtra("FotoProfil", R.drawable.kucing10);
                intent1.putExtra("username", "ay.yay_");
                intent1.putExtra("following", "200K");
                intent1.putExtra("followers", "50k");
                intent1.putExtra("postprofil", R.drawable.post10);
                startActivity(intent1);
            }
        });
    }

}