package com.example.praktikum3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class StoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story);

        ImageView ivstory = findViewById(R.id.story);
        CircleImageView cvstory = findViewById(R.id.cv_story);
        TextView tvusername = findViewById(R.id.usernamestory);


        Intent intent = getIntent();

        int story = intent.getIntExtra("story",0);
        int cv_story = intent.getIntExtra("cv_story", 0);
        String usernamestory = intent.getStringExtra("username");

        ivstory.setImageResource(story);
        cvstory.setImageResource(cv_story);
        tvusername.setText(usernamestory);

        tvusername.setOnClickListener(v -> {
            if(usernamestory.equals("biwarchive")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing1);
                storyintent1.putExtra("username", "biwarchive");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post1);
                startActivity(storyintent1);
            }if(usernamestory.equals("xisalsaa")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing2);
                storyintent1.putExtra("username", "xisalsaa");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post2);
                startActivity(storyintent1);
            }if(usernamestory.equals("nakitssss")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing3);
                storyintent1.putExtra("username", "nakitssss");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post3);
                startActivity(storyintent1);
            }if(usernamestory.equals("serilll")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing4);
                storyintent1.putExtra("username", "serilll");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post4);
                startActivity(storyintent1);
            }if(usernamestory.equals("dipsieyyy")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing5);
                storyintent1.putExtra("username", "dipsieyyy");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post5);
                startActivity(storyintent1);
            }if(usernamestory.equals("raihnhr")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing6);
                storyintent1.putExtra("username", "raihnhr");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post6);
                startActivity(storyintent1);
            }if(usernamestory.equals("awinkkk")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing7);
                storyintent1.putExtra("username", "awinkkk");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post7);
                startActivity(storyintent1);
            }if(usernamestory.equals("auliyaspryg")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing8);
                storyintent1.putExtra("username", "auliyaspryg");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post8);
                startActivity(storyintent1);
            }if(usernamestory.equals("yumyeyyy")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing8);
                storyintent1.putExtra("username", "yumyeyyy");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post8);
                startActivity(storyintent1);
            }if(usernamestory.equals("ay.yay_")) {
                Intent storyintent1 = new Intent(StoryActivity.this, ProfileActivity.class);
                storyintent1.putExtra("FotoProfil",R.drawable.kucing9);
                storyintent1.putExtra("username", "ay.yay_");
                storyintent1.putExtra("following", "200k");
                storyintent1.putExtra("followers", "50K");
                storyintent1.putExtra("postprofil", R.drawable.post9);
                startActivity(storyintent1);
            }
        });





    }
}