package com.example.praktikum3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends
        RecyclerView.Adapter<StoryAdapter.ViewHolder> {
    private final ArrayList<Story> stories;
    private Context context;
    public StoryAdapter(ArrayList<Story> stories, Context context) {
        this.context = context;
        this.stories = stories;
    }
    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup
                                                                parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder,
                                 int position) {
        Story story = stories.get(position);
        holder.setData(story);

        holder.Image.setOnClickListener(v ->{
            if(stories.get(position).getImage().equals(R.drawable.kucing1)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story1);
                intent.putExtra("cv_story", R.drawable.kucing1);
                intent.putExtra("username", "biwarchive");
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.kucing2)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("cv_story", R.drawable.kucing2);
                intent.putExtra("username", "xisalsaa");
                intent.putExtra("story", R.drawable.story2);
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.kucing3)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story3);
                intent.putExtra("cv_story", R.drawable.kucing3);
                intent.putExtra("username", "nakitssss");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing4)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("cv_story", R.drawable.kucing4);
                intent.putExtra("username", "serilll");
                intent.putExtra("story", R.drawable.story4);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing5)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story5);
                intent.putExtra("cv_story", R.drawable.kucing5);
                intent.putExtra("username", "dipsieyyy");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing6)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story6);
                intent.putExtra("cv_story", R.drawable.kucing6);
                intent.putExtra("username", "raihnhr");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing7)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story7);
                intent.putExtra("cv_story", R.drawable.kucing7);
                intent.putExtra("username", "awinkkk");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing8)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story8);
                intent.putExtra("cv_story", R.drawable.kucing8);
                intent.putExtra("username", "auliyaspryg");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing9)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story9);
                intent.putExtra("cv_story", R.drawable.kucing9);
                intent.putExtra("username", "yumyeyyy");
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.kucing10)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("story", R.drawable.story10);
                intent.putExtra("cv_story", R.drawable.kucing10);
                intent.putExtra("username", "ay.yay_");
                context.startActivity(intent);
            }
        });

    }
    @Override
    public int getItemCount() {

        return stories.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView Username;
        private final ImageView Image;

        @SuppressLint("WrongViewCast")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Username = itemView.findViewById(R.id.tv_username);
            Image = itemView.findViewById(R.id.tv_story);
        }

        public void setData(Story story) {
            Username.setText(story.getName());
            Image.setImageResource(story.getImage());
        }
    }
}
