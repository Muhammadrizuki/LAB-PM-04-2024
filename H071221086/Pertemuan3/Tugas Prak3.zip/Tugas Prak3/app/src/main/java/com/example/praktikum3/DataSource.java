package com.example.praktikum3;

import com.example.praktikum3.R;
import com.example.praktikum3.Story;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Story> stories = generateDummyStory();
    private static ArrayList<Story> generateDummyStory() {
        ArrayList<Story> students = new ArrayList<>();
        students.add(new Story("biwarchive",
                R.drawable.kucing1));
        students.add(new Story("xisalsaa",
                R.drawable.kucing2));
        students.add(new Story("nakitssss",
                R.drawable.kucing3));
        students.add(new Story("serilll.",
                R.drawable.kucing4));
        students.add(new Story("dipsieyyy",
                R.drawable.kucing5));
        students.add(new Story("raihnhr",
                R.drawable.kucing6));
        students.add(new Story("awinkk",
                R.drawable.kucing7));
        students.add(new Story("auliyaspryg",
                R.drawable.kucing8));
        students.add(new Story("yumyeyyy",
                R.drawable.kucing9));
        students.add(new Story("ay.yay_",
                R.drawable.kucing10));
        return students;
    }

    public static ArrayList<Postingan> postingans = generateDummyPostingan();
    private static ArrayList<Postingan> generateDummyPostingan(){
        ArrayList<Postingan> postingans = new ArrayList<>();
        postingans.add(new Postingan("biwarchive", " “Stay wild, stay free.”", R.drawable.post1));
        postingans.add(new Postingan("xisalsaa", " “Adventure awaits just outside your door“ ", R.drawable.post2));
        postingans.add(new Postingan("nakitssss", " “Be the reason someone smiles today“ ", R.drawable.post3));
        postingans.add(new Postingan("serilll", " “In a world of filters, be your own authentic self.” ", R.drawable.post4));
        postingans.add(new Postingan("dipsieyyy", " “Love is not finding someone to live with, it’s finding someone you can’t live without“ ", R.drawable.post5));
        postingans.add(new Postingan("raihnhr", " “Be a voice, not an echo“ ", R.drawable.post6));
        postingans.add(new Postingan("awinkkk", " “Haters gonna hate, I’m gonna keep shining“ ", R.drawable.post7));
        postingans.add(new Postingan("auliyaspryg", " “Believe you can and you’re halfway there“ ” – Theodore Roosevelt", R.drawable.post8));
        postingans.add(new Postingan("yumyeyyy", " “The future belongs to those who believe in the beauty of their dreams” – Eleanor Roosevelt", R.drawable.post9));
        postingans.add(new Postingan("ay.yay_", " “Life is 10% what happens to us and 90% how we react to it“ ", R.drawable.post10));
        return postingans;
    }

}