package com.example.praktikum3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView ivProfile = findViewById(R.id.iv_profil);
        TextView tvUsername = findViewById(R.id.userprofil);
        TextView tvFollowing = findViewById(R.id.jumlahfollowing);
        TextView tvFollowers = findViewById(R.id.jumlahfollowers);
        ImageView ivPost = findViewById(R.id.profilpost);

        Intent intent = getIntent();

        int fotoProfile = intent.getIntExtra("FotoProfil", 0);
        String username = intent.getStringExtra("username");
        String following = intent.getStringExtra("following");
        String followers = intent.getStringExtra("followers");
        int postProfile = intent.getIntExtra("postprofil",0);

        ivProfile.setImageResource(fotoProfile);
        tvUsername.setText(username);
        tvFollowing.setText(following);
        tvFollowers.setText(followers);
        ivPost.setImageResource(postProfile);

        ivProfile.setOnClickListener(v -> {
            if(fotoProfile == R.drawable.kucing1){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story1);
                storyintent.putExtra("cv_story",R.drawable.kucing1);
                storyintent.putExtra("username", "biwarchive");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing2){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story2);
                storyintent.putExtra("cv_story", R.drawable.kucing2);
                storyintent.putExtra("username", "xisalsaa");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing3){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story3);
                storyintent.putExtra("cv_story",R.drawable.kucing3);
                storyintent.putExtra("username", "nakitssss");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing4){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story4);
                storyintent.putExtra("cv_story", R.drawable.kucing4);
                storyintent.putExtra("username", "serilll");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing5){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story5);
                storyintent.putExtra("cv_story", R.drawable.kucing5);
                storyintent.putExtra("username","dipsieyyy");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing6){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story6);
                storyintent.putExtra("cv_story", R.drawable.kucing6);
                storyintent.putExtra("username", "raihnhr");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing7){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story7);
                storyintent.putExtra("cv_story", R.drawable.kucing7);
                storyintent.putExtra("username", "awinkk");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing8){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story8);
                storyintent.putExtra("cv_story", R.drawable.kucing8);
                storyintent.putExtra("username", "auliyaspryg");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing9){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story9);
                storyintent.putExtra("cv_story", R.drawable.kucing9);
                storyintent.putExtra("username", "yumyeyyy");
                startActivity(storyintent);
            }if(fotoProfile == R.drawable.kucing10){
                Intent storyintent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyintent.putExtra("story",R.drawable.story10);
                storyintent.putExtra("cv_story", R.drawable.kucing10);
                storyintent.putExtra("username", "ay.yay_");
                startActivity(storyintent);
            }
        });

        ivPost.setOnClickListener(v -> {
            if(postProfile == R.drawable.post1){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post1);
                postintent.putExtra("username", "biwarchive");
                postintent.putExtra("caption", "“Stay wild, stay free.”");
                startActivity(postintent);
            } if(postProfile == R.drawable.post2){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post2);
                postintent.putExtra("username", "xisalsaa");
                postintent.putExtra("caption", "“Adventure awaits just outside your door“");
                startActivity(postintent);
            }if(postProfile == R.drawable.post3){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post3);
                postintent.putExtra("username", "nakitssss");
                postintent.putExtra("caption", "“Be the reason someone smiles today“");
                startActivity(postintent);
            }if(postProfile == R.drawable.post4){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post4);
                postintent.putExtra("username", "serilll");
                postintent.putExtra("caption", "“In a world of filters, be your own authentic self.”");
                startActivity(postintent);
            }if(postProfile == R.drawable.post5){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post5);
                postintent.putExtra("username", "dipsieyyy");
                postintent.putExtra("caption", "“Love is not finding someone to live with, it’s finding someone you can’t live without“");
                startActivity(postintent);
            }if(postProfile == R.drawable.post6){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post6);
                postintent.putExtra("username", "raihnhr");
                postintent.putExtra("caption", "“Be a voice, not an echo“");
                startActivity(postintent);
            }if(postProfile == R.drawable.post7){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post7);
                postintent.putExtra("username", "awinkkk");
                postintent.putExtra("caption", "“Haters gonna hate, I’m gonna keep shining“");
                startActivity(postintent);
            }if(postProfile == R.drawable.post8){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post8);
                postintent.putExtra("username", "auliyaspryg");
                postintent.putExtra("caption", "“Believe you can and you’re halfway there“ ” – Theodore Roosevelt");
                startActivity(postintent);
            }if(postProfile == R.drawable.post9){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post9);
                postintent.putExtra("username", "yumyeyyy");
                postintent.putExtra("caption", "“The future belongs to those who believe in the beauty of their dreams” – Eleanor Roosevelt");
                startActivity(postintent);
            }if(postProfile == R.drawable.post10){
                Intent postintent = new Intent(ProfileActivity.this, PostinganActivity.class);
                postintent.putExtra("postingan", R.drawable.post10);
                postintent.putExtra("username", "ay.yay_");
                postintent.putExtra("caption", "Life is 10% what happens to us and 90% how we react to it“ ");
                startActivity(postintent);
            }
        });

    }
}