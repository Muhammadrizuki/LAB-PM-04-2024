package com.example.praktikum3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostinganAdapter extends RecyclerView.Adapter<PostinganAdapter.ViewHolder> {
    private final ArrayList<Postingan> postingans;
    private Context context;

    public PostinganAdapter(ArrayList<Postingan> postingans, Context context){
        this.context = context;
        this.postingans = postingans;
    }

    @NonNull
    @Override
    public PostinganAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostinganAdapter.ViewHolder holder, int position) {
        Postingan postingan = postingans.get(position);
        holder.setData(postingan);

        holder.username.setOnClickListener(v -> {
            if (postingans.get(position).getUsername().equals("biwarchive")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil",R.drawable.kucing1);
                intent.putExtra("username","biwarchive");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil",R.drawable.post1);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("xisalsaa")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil",R.drawable.kucing2);
                intent.putExtra("username","xisalsaa");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil",R.drawable.post2);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("nakitssss")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil",R.drawable.kucing3);
                intent.putExtra("username","nakitssss");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil",R.drawable.post3);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("serilll")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil",R.drawable.kucing4);
                intent.putExtra("username","serilll");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil",R.drawable.post4);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("dipsieyyy")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing5);
                intent.putExtra("username", "dipsieyyy");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post5);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("raihnhr")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing6);
                intent.putExtra("username", "raihnhr");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post6);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("awinkk")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing7);
                intent.putExtra("username", "awinkk");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post7);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("auliyaspryg")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing8);
                intent.putExtra("username", "auliyaspryg");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post8);
                context.startActivity(intent);
            } if (postingans.get(position).getUsername().equals("yumyeyyy")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing9);
                intent.putExtra("username", "awinkk");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post9);
                context.startActivity(intent);
            }if (postingans.get(position).getUsername().equals("ay.yay_")) {
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FotoProfil", R.drawable.kucing10);
                intent.putExtra("username", "awinkk");
                intent.putExtra("following", "200K");
                intent.putExtra("followers", "50k");
                intent.putExtra("postprofil", R.drawable.post10);
                context.startActivity(intent);
            }


        });

    }

    @Override
    public int getItemCount() {
        return postingans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView gambar;
        private final TextView username;
        private final TextView caption;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            gambar = itemView.findViewById(R.id.post_image);
            username = itemView.findViewById(R.id.username);
            caption = itemView.findViewById(R.id.post_caption);

        }

        public void setData(Postingan postingan) {
            username.setText(postingan.getUsername());
            caption.setText(postingan.getCaption());
            gambar.setImageResource(postingan.getPost());


            
        }
    }
}
