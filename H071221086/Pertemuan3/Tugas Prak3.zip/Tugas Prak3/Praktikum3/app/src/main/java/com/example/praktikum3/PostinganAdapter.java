package com.example.praktikum3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostinganAdapter extends RecyclerView.Adapter<PostinganAdapter.ViewHolder> {
    private final ArrayList<Postingan> postingans;

    public PostinganAdapter(ArrayList<Postingan> postingans) {
        this.postingans = postingans;
    }

    @NonNull
    @Override
    public PostinganAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostinganAdapter.ViewHolder holder, int position) {
        Postingan postingan = postingans.get(position);
        holder.setData(postingan);

    }

    @Override
    public int getItemCount() {
        return postingans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView gambar;
        private final TextView username;
        private final TextView caption;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            gambar = itemView.findViewById(R.id.post_image);
            username = itemView.findViewById(R.id.post_username);
            caption = itemView.findViewById(R.id.post_caption);
        }

        public void setData(Postingan postingan) {
            username.setText(postingan.getUsername());
            caption.setText(postingan.getCaption());
            gambar.setImageResource(postingan.getPost());
            
        }
    }
}
