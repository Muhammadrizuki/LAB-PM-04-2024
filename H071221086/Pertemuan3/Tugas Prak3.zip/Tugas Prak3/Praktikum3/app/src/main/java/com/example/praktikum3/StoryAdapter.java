package com.example.praktikum3;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends
        RecyclerView.Adapter<StoryAdapter.ViewHolder> {
    private final ArrayList<Story> stories;
    public StoryAdapter(ArrayList<Story> stories) {
        this.stories = stories;
    }
    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup
                                                                parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder,
                                 int position) {
        Story story = stories.get(position);
        holder.setData(story);
    }
    @Override
    public int getItemCount() {
        return stories.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView Story;
        private final ImageView Username;

        @SuppressLint("WrongViewCast")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Story = itemView.findViewById(R.id.tv_story);
            Username = itemView.findViewById(R.id.tv_username);
        }

        public void setData(Story story) {
            Story.setText(story.getName());
            Username.setImageResource(story.getImage());
        }
    }
}
