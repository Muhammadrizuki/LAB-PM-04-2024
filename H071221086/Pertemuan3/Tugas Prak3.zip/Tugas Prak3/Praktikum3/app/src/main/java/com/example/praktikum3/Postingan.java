package com.example.praktikum3;

import android.os.Parcel;
import android.os.Parcelable;

public class Postingan implements Parcelable {

    private String username;
    private String caption;
    private Integer post;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Integer getPost() {
        return post;
    }

    public void setPost(Integer post) {
        this.post = post;
    }

    public Postingan(String username, String caption, Integer image){
        this.username = username;
        this.caption = caption;
        this.post = post;
    }

    protected Postingan(Parcel in) {
        username = in.readString();
        caption = in.readString();
        if (in.readByte() == 0) {
            post = null;
        } else {
            post = in.readInt();
        }
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(username);
        dest.writeString(caption);
        if (post == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(post);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Postingan> CREATOR = new Creator<Postingan>() {
        @Override
        public Postingan createFromParcel(Parcel in) {
            return new Postingan(in);
        }

        @Override
        public Postingan[] newArray(int size) {
            return new Postingan[size];
        }
    };
}
