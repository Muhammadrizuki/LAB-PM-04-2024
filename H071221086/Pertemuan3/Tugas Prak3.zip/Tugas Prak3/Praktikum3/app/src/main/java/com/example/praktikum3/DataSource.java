package com.example.praktikum3;

import com.example.praktikum3.R;
import com.example.praktikum3.Story;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Story> stories = generateDummyStory();
    private static ArrayList<Story> generateDummyStory() {
        ArrayList<Story> students = new ArrayList<>();
        students.add(new Story("biwarchive",
                R.drawable.kucing1));
        students.add(new Story("xisalsa",
                R.drawable.kucing2));
        students.add(new Story("nakitssss",
                R.drawable.kucing3));
        students.add(new Story("serilll.",
                R.drawable.kucing4));
        students.add(new Story("nakitssss",
                R.drawable.kucing3));
        students.add(new Story("serilll.",
                R.drawable.kucing4));
        students.add(new Story("nakitssss",
                R.drawable.kucing3));
        students.add(new Story("serilll.",
                R.drawable.kucing4));
        students.add(new Story("nakitssss",
                R.drawable.kucing3));
        students.add(new Story("serilll.",
                R.drawable.kucing4));
        return students;
    }

    public static ArrayList<Postingan> postingans = generateDummyPostingan();
    private static ArrayList<Postingan> generateDummyPostingan(){
        ArrayList<Postingan> postingans = new ArrayList<>();
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing1));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing2));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing3));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing4));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing1));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing2));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing3));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing4));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing1));
        postingans.add(new Postingan("biwarchive", " hahahahahaha", R.drawable.kucing2));
        return postingans;
    }

}