package com.example.praktikum3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvStory =findViewById(R.id.rv_story);
        rvStory.setHasFixedSize(true);

        StoryAdapter Story =new StoryAdapter(DataSource.stories);
        rvStory.setAdapter(Story);

        RecyclerView rvPost =findViewById(R.id.rv_post);
        rvStory.setHasFixedSize(true);

        PostinganAdapter Post =new PostinganAdapter(DataSource.postingans);
        rvPost.setAdapter(Post);

        rvStory.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false));
    }
}